import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Projects from './components/Projects';
import Features from './components/Features';
import Todolist from './components/Todolist';


function App() {
  return (
    <div className="App">
       <BrowserRouter>
      <Routes>
        <Route path="/" element={<Projects/>}/>
          <Route path="/feature/:id" element={<Features/>} />
          <Route path="/todolist/:featureIds/:projectIds" element={<Todolist/>} />
        
      </Routes>
    </BrowserRouter>
    </div>
  );
}

export default App;
