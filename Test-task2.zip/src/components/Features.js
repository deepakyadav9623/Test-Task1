import React, { useEffect, useId, useState } from "react";
import {useNavigate} from "react-router-dom";
import { useDispatch, useSelector } from 'react-redux'
import { addFeature,deleteFeature,updateFeature } from "../redux/actions/action";
import { useParams } from "react-router";

const Features = () => {
  const id1=useParams();

  const project1=useSelector(state=>state)
  const dispatch= useDispatch()
  const [inputProject, setInputProject] = useState();
  const [isVisible, setIsVisible] = useState();
  const [updatedInput, setUpatedInput] = useState();
  const navigate= useNavigate();
  // console.log(101010,project1.reducer.feature)
  const handleChange = (e) => {
    setInputProject(e.target.value);
  };



  const clickEvent = () => {
    const name = inputProject;
    
    const ids=[project1.reducer.feature.length ]
    const id = Math.max.apply(null, ids) + 1;
    const projectId=id1.id;
    const post = { projectId: projectId, id: id, name: name, };
    console.log(11111222333,post)
  
     dispatch(addFeature(post))
  };

  const deleteProject = (id) => {
    console.log("deleed");
    dispatch(deleteFeature(id))

  };

  const editproject = (id, name) => {
    console.log("edited", id);
    setIsVisible(id);
    setUpatedInput(name);
  };

  const updateChange = (e) => {
    setUpatedInput(e.target.value);
  };

  const updateEvent = (id, name,projectId) => {
    dispatch(updateFeature(id,name,projectId))
    setIsVisible('')
  };

  const jumpEvent=(featureIds,projectIds)=>{
      navigate(`/todolist/${featureIds}/${projectIds}`)
  }

  return (
    <div>
      <div> 
      <button onClick={() => navigate(-1)}> Go back </button>
      </div>
      <h1>{id1.id}</h1>   
      {
       project1.reducer.feature.filter((item)=> item.projectId===id1.id).map((features,index)=>{
       
         return(
           <div key={index}>
             {
               isVisible===features.id ? 
               <div>
                <input
                  type="text"
                  value={updatedInput}
                  onChange={updateChange}
                />
                <button
                  onClick={() => {
                    updateEvent(features.id, updatedInput,features.projectId);
                  }}
                >
                  Update
                </button>
              </div>:
               <div>
                <p onClick={()=>{jumpEvent(features.id,id1.id)}}> {features.name} </p>
             <button onClick={()=>{editproject(features.id,features.name)}}>Edit</button>
             <button onClick={()=>{deleteProject(features.id)}}>Delete</button></div>
             }
             
           </div>
         )
        })
      }   
      <input type="text" onChange={handleChange} />
      <button onClick={clickEvent}> Add Features</button>
  
      

    </div>
  )
}

export default Features