import React, { useEffect, useId, useState } from "react";
import {useNavigate} from "react-router-dom";
import { useDispatch, useSelector } from 'react-redux'
import { addProject,deleteProjects,updateProject } from "../redux/actions/action";

const Projects = () => {

  const project1=useSelector(state=>state)
  const dispatch= useDispatch()
  const [inputProject, setInputProject] = useState();

   const [isVisible, setIsVisible] = useState();
  const [updatedInput, setUpdateInput] = useState();
  const navigate= useNavigate();
  const [ids1,setIds]=useState(0);
  
  // console.log(101010,project1.reducer.project)
  const handleChange = (e) => {
    // console.log("handleChange");
    setInputProject(e.target.value);
  };

  const clickEvent = () => {
    const name = inputProject;

    const ids=[project1.reducer.project.length ]
    const id = Math.max.apply(null, ids) + 1;
  
    const post = { id: id, name: name };
  
     dispatch(addProject(post))

  };

  const deleteProject = (id) => {
    console.log("deleted",id);
    dispatch(deleteProjects(id))
    // setIds(id-ids1)

  };

  const editproject = (id, name) => {
    console.log("edited", id);
    setIsVisible(id);
    setUpdateInput(name);
  };

  const updateChange = (e) => {
    setUpdateInput(e.target.value);
  };

  const updateEvent = (id,name) => {
    console.log("updated ", id);
    console.log("updated2 ", name);
    dispatch(updateProject(id,name))

    setIsVisible('')
  };

  
  const jumpEvent=(id,name)=>{
      console.log("jumped",name)
      navigate(`/feature/${id}`)

  }
  return (
    <div>

      {project1.reducer.project.map((project, index) => {
        return (
          <div key={index}>
            {isVisible === project.id ? (
              <div>
                <input
                  type="text"
                  value={updatedInput}
                  onChange={updateChange}
                />
                <button
                  onClick={() => {
                    updateEvent(project.id, updatedInput);
                  }}
                >
                  Update
                </button>
              </div>
            ) : (
              <div>
                <p onClick={()=>{jumpEvent(project.id,project.name)}}>
                  {project.id} : {project.name} &nbsp;
                </p>
              </div>
            )}
            <button
              onClick={() => {
                editproject(project.id, project.name);
              }}
            >
              Edit
            </button>
            <button
              onClick={() => {
                deleteProject(project.id);
              }}
            >
            Delete
            </button>{" "}
            <br />
          </div>
        );
      })}
      <br />
      <br />
      <input type="text" onChange={handleChange} />
      <button onClick={clickEvent}> Add Projects</button>
    </div>
  );
};
export default Projects;
