import React, { useEffect, useId, useState } from "react";
import {useNavigate} from "react-router-dom";
import { useDispatch, useSelector } from 'react-redux'
import { addTodos,deleteTodos,updateTodos } from "../redux/actions/action";
import { useParams } from "react-router";

const Todolist = () => {
  const id2=useParams();
  
  const project1=useSelector(state=>state)
  const dispatch= useDispatch()

  const [inputProject, setInputProject] = useState();
  const [isVisible, setIsVisible] = useState();
  const [updatedInput, setUpatedInput] = useState();
  const navigate= useNavigate();

  const handleChange = (e) => {
    setInputProject(e.target.value);
  };

  const clickEvent = () => {
    const name = inputProject;
    const featureId=id2.featureIds;
    const projectId=id2.projectIds
   
    const completed=false;
    const ids=[project1.reducer.todos.length ]
    const id = Math.max.apply(null, ids) + 1;
    //  const id=todos.length+1
    const post = { projectId:projectId,featureId: featureId, name: name,id: id,completed:completed };
    dispatch(addTodos(post))
  };

  const deleteProject = (id) => {
    
    console.log("first", id);
    dispatch(deleteTodos(id))
  };

  const editproject = (id, name) => {
    console.log("edited", id);
    setIsVisible(id);
    setUpatedInput(name);
  };
  const updateChange = (e) => {
    setUpatedInput(e.target.value);
  };

  const updateEvent = (id, name,projectId,featureId) => {
    console.log("updated ", id);
    console.log("updated2 ", name);
    dispatch(updateTodos(id,name,projectId,featureId))
    setIsVisible('')
  };
  
  const toggleTodos=(id)=>{
    project1.reducer.todos.find((item)=>{
      if(item.id===id){
        item.completed=!item.completed; 
      }
      return (project1.reducer.todos)
    })
    console.log(101010,project1.reducer.todos)

  }
  return (
    <div>
      <div> 
      <button onClick={() => navigate(-1)}> Go back </button>
      </div>
      <h1>{id2.featureIds}</h1>   
      {
        project1.reducer.todos.filter((item)=>item.featureId===id2.featureIds&&item.projectId===id2.projectIds).map((todoss,index)=>{
         return(
           <div key={index}>
             {
               isVisible===todoss.id ? 
               <div>
                <input
                  type="text"
                  value={updatedInput}
                  onChange={updateChange}
                />
                <button
                  onClick={() => {
                    updateEvent(todoss.id, updatedInput,todoss.projectId,todoss.featureId);
                  }}
                >
                  Update
                </button>
              </div>:
               <div>
                <p >  {todoss.name}  <input style={{ width:15}} type="checkbox" onChange={()=>{toggleTodos(todoss.id)}}/></p>
             {/* <button onClick={()=>{toggleTodos(todoss.id)}}></button> */}
             <button onClick={()=>{editproject(todoss.id,todoss.name)}}>Edit</button>
             <button onClick={()=>{deleteProject(todoss.id)}}>Delete</button>
            
             </div>
             }
             
           </div>
         )
        })
      }   
      <input type="text" onChange={handleChange} />
      <button onClick={clickEvent}> Add todoss</button>
  
      

    </div>
  )
}

export default Todolist