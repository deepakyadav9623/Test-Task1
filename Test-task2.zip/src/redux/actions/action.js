
export const getProject = () => {
    console.log(333333)
     return {
       type: "GET_PROJECT"
     };
  };
  
  export const addProject = (project) => {
  //  console.log(55555,project)
     return {
       type: "ADD_PROJECT",
       payload: project
     };
  };
  
  export const deleteProjects = (id) => {
     return {
       type: "DELETE_PROJECT",
       payload: id
     };
  };
  
  export const updateProject = (id,name) => {
     return {
       type: "UPDATE_PROJECT",
       payload: {id:id,name:name}
     };
  };
  
export const getFeature = () => {
    console.log(333333)
     return {
       type: "GET_FEATURE"
     };
  };
  
  export const addFeature = (feature) => {
  //  console.log(55555,project)
     return {
       type: "ADD_FEATURE",
       payload: feature
     };
  };
  
  export const deleteFeature = (id) => {
     return {
       type: "DELETE_FEATURE",
       payload: id
     };
  };
  
  export const updateFeature = (id,name,projectId) => {
     return {
       type: "UPDATE_FEATURE",
       payload: {id:id,name:name,projectId:projectId}
     };
  };
export const getTodos = () => {
    console.log(333333)
     return {
       type: "GET_TODOS"
     };
  };
  
  export const addTodos = (feature) => {
  //  console.log(55555,project)
     return {
       type: "ADD_TODOS",
       payload: feature
     };
  };
  
  export const deleteTodos = (id) => {
     return {
       type: "DELETE_TODOS",
       payload: id
     };
  };
  
  export const updateTodos = (id,name,projectId,featureId) => {
     return {
       type: "UPDATE_TODOS",
       payload: {id:id,name:name,projectId:projectId,featureId:featureId}
     };
  };
  