
const initialState =  {
    project: [],
    feature:[],
    todos:[]
   
  }
  const reducer = (state = initialState, action) => {
    console.log(666666666, action.type)
    console.log(666611111, action.payload)
  
    switch (action.type) {
      case "GET_PROJECT":
        return {...state};
      case "ADD_PROJECT":
        return {...state, project: state.project.concat(action.payload) };
      case "DELETE_PROJECT":
        const data1 = state.project.filter((project) => project.id !== action.payload);
        const data5 = state.feature.filter((item)=>item.projectId!=action.payload);
        const data6=state.todos.filter((item)=>item.projectId!=action.payload)
        return {...state, project: data1,feature:data5,todos:data6};
      case "UPDATE_PROJECT":
        let obj={id:action.payload.id,name:action.payload.name}
        state.project.splice(action.payload.id-1,1,obj)
        return {...state, project: state.project};


      case "GET_FEATURE":
        return {...state};
      case "ADD_FEATURE":
        return {...state, feature: state.feature.concat(action.payload) };
      case "DELETE_FEATURE":
        const data = state.feature.filter((feature) => feature.id !== action.payload);
        const data7=state.todos.filter((item)=>item.featureId!=action.payload)
        return {...state, feature: data,todos:data7};
      case "UPDATE_FEATURE":
        let obj1={id:action.payload.id,name:action.payload.name,projectId:action.payload.projectId}
        state.feature.splice(action.payload.id-1,1,obj1)
        return {...state, feature: state.feature};


      case "GET_TODOS":
        return {...state};
      case "ADD_TODOS":
        return {...state, todos: state.todos.concat(action.payload) };
      case "DELETE_TODOS":
        const data2 = state.todos.filter((todos) => todos.id !== action.payload);
        return {...state, todos: data2};
      case "UPDATE_TODOS":
        let obj2={id:action.payload.id,name:action.payload.name,projectId:action.payload.projectId,featureId:action.payload.featureId}
        state.todos.splice(action.payload.id-1,1,obj2)
        return {...state, todos: state.todos};
      default:
        return state;
    }
  };
  
  export default reducer;
  
  
  
  