import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from './components/home';
import Posts from './components/posts';
import Users from './components/users';
import Comments from './components/comments';
function App() {
  return (
    <BrowserRouter>
    <Routes>
      <Route path="/" element={<Home/>}> </Route>
      <Route path="/posts/:id" element={<Posts/>}> </Route>
      <Route path="/users/:id" element={<Users/>}> </Route>
      <Route path="/comments/:id" element={<Comments/>}> </Route>
    </Routes>
  </BrowserRouter>
  );
}

export default App;
