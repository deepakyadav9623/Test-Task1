import React from 'react'
import { useEffect } from 'react'
import { useSelector } from 'react-redux'
import { useDispatch } from 'react-redux'
import { useNavigate } from 'react-router'
import { getPost,getUsers,getComments } from '../redux/actions/action'
import { useState } from 'react'
import FilterResults from 'react-filter-search';

const Home = () => {
    const [value,setValue]=useState("");
    const dispatch=useDispatch()
    const data=useSelector(state=>state)
    const navigate=useNavigate() 
console.log(11111,data)
    useEffect(()=>{

    //   axios.get(`https://jsonplaceholder.typicode.com/users`)
    //   .then(res => {
       
    //     setData1(res.data)
    //     // setUsername(res.data.map((item)=>item.username))
    //   })
        dispatch(getUsers())
        dispatch(getPost())
        dispatch(getComments())

    },[])

    const postDetails=(id)=>{
        console.log("clicked post detauils",id)
        navigate(`/posts/${id}`)

    }
    const userDetails=(id)=>{
        console.log("clicked post detauils",id)
        navigate(`/users/${id}`)
    }

    const handleChange=(e)=>{
      setValue(e.target.value)
    }

  return (
    <div>
         <div>
        <input type="text" value={value} onChange={handleChange}  />
        
        <FilterResults
          value={value}
          data={data.Reducers.getUsers}
          renderResults={results => (
            <div>
              {results.map(el => (
                <div>
                  <span>{el.username}</span>
                  {/* <span>{el.email}</span> */}
                </div>
              ))}
            </div>
          )}
        />

        
      </div>

      <div>
        <table class="table table-bordered">
          <thead>
            <tr>
              <th scope="col">Id</th>
              <th scope="col">Title</th>
              <th scope="col">Username</th>
            </tr>
          </thead>
          <tbody>
            {data.Reducers.getPost.map((posts, index) => {
              return (
                <tr key={index}>
                  <td> {posts.id}</td>
                  <td onClick={()=>{postDetails(posts.id)}}>{posts.title}</td>
                  <td onClick={()=>{userDetails(posts.userId)}}>
                    {data.Reducers.getUsers.filter((item) => item.id === posts.userId).map((item) => item.username)}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Home