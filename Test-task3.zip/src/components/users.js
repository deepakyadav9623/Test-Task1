import React from 'react'
import { useSelector } from 'react-redux'
import { useNavigate } from 'react-router'
import { useParams } from 'react-router'

const Users = () => {
  const navigate=useNavigate()
  const {id} =useParams()
  const data=useSelector(state=>state)
  console.log(33333,data.Reducers.getUsers)
  return (
    <div className='App-header'>
      <div className='App'>
      <button onClick={() => navigate(-1)}> Back!!!</button><br/><br/>
      <h1>User Detail of User {id}</h1>

      </div>
      <br/>
      {
        data.Reducers.getUsers.filter((item)=>item.id==id).map((items,index)=>{
          return(
            <div key={index}>
              <p>Name :  {items.name}</p>
              <p>User Name :  {items.username}</p>
              <p>Email :  {items.email}</p>
              <p>Website :  {items.website}</p>
              <p>Company Name :  {items.company.name}</p>
              <p>Company bs :  {items.company.bs}</p>
              <p>Company CatchPhrase :  {items.company.catchPhrase}</p>
            </div>
          )
        })
      }
      </div>
  )
}

export default Users