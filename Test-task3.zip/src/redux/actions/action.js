import axios from "axios"

const GET_POST="GET_POST"
const GET_USERS="GET_USERS"
const GET_COMMENTS="GET_COMMENTS"
const GET_POST_ERROR="GET_POST_ERROR"
const GET_USERS_ERROR="GET_USERS_ERROR"
const GET_COMMENTS_ERROR="GET_COMMENTS_ERROR"

export const getPost = () => {
    
    return (dispatch)=>{
        axios.get(`https://jsonplaceholder.typicode.com/posts`)
        .then((res)=>{
            dispatch(getPostSuccess(res.data))
          
        }).catch((error)=>{
            dispatch(getPostError(error.message))
        })
    }
  }


  const getPostSuccess=(data)=>{
    return{
        type:GET_POST,
        payload:data
    }
}

const getPostError=(data)=>{
    return{
        type:GET_POST_ERROR,
        payload:data
    }
}
export const getUsers = (data) => {
    
    return (dispatch)=>{
        axios.get(`https://jsonplaceholder.typicode.com/users`)
        .then((res)=>{
            dispatch(getUsersSuccess(res.data))
          
        }).catch((error)=>{
            dispatch(getUsersError(error.message))
        })
    }
  }


  const getUsersSuccess=(data)=>{
    return{
        type:GET_USERS,
        payload:data
    }
}

const getUsersError=(data)=>{
    return{
        type:GET_USERS_ERROR,
        payload:data
    }
}
export const getComments = (data) => {
    
    return (dispatch)=>{
        axios.get(`https://jsonplaceholder.typicode.com/comments`)
        .then((res)=>{
            dispatch(getCommentsSuccess(res.data))
          
        }).catch((error)=>{
            dispatch(getCommentsError(error.message))
        })
    }
  }


  const getCommentsSuccess=(data)=>{
    return{
        type:GET_COMMENTS,
        payload:data
    }
}

const getCommentsError=(data)=>{
    return{
        type:GET_COMMENTS_ERROR,
        payload:data
    }
}