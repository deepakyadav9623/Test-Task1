
const initialState={
    getPost:[],
    getPosterror:[],
    getUsers:[],
    getUserserror:[],
    getComments:[],
    getCommentserror:[],

}
const Reducers = (state = initialState,action) => {
    console.log(666666666, action.type);
    console.log(666611111, action.payload);
    

    switch (action.type) {

      case "GET_POST":
        return { ...state,  getPost:action.payload};
      case "GET_POST_ERROR":
        return { ...state, getPosterror: action.payload };
      case "GET_USERS":
        return { ...state,  getUsers:action.payload};
      case "GET_USERS_ERROR":
        return { ...state, getUserserror: action.payload };
      case "GET_COMMENTS":
        return { ...state,  getComments:action.payload};
      case "GET_COMMENTS_ERROR":
        return { ...state, getCommentserror: action.payload };
      default:
        return state;
    }
}

export default Reducers;