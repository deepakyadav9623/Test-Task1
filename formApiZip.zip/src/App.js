import './App.css';
import { Navigate } from 'react-router-dom';
import Data from './components/Home';
import {
  BrowserRouter,
  Routes,
  Route,
} from "react-router-dom";
import { Form } from './components/Register';
import React from 'react';
import { Login } from './components/Login';
import Dashboard from './components/dashboard';
import LogOut from './components/LogOut';

const PrivateRoute =()=>{
  const token=localStorage.getItem("token");
  return token ? <Dashboard/> : <Navigate to="/login" />;
}

function App() {
  return (
    <div >
    <BrowserRouter>
 
    
      <Routes>
         <Route path="/form" element={<Form/>}/>
         <Route path="/" element={<Data/>} exact={true} />
         <Route path="/login" element={<Login/>}/>
         <Route path="/logout" element={<LogOut/>}/>
         {/* <Route path="/dashboard" element={<Dashboard/>}/> */}
         <Route
          path="/dashboard"
          element={
            <PrivateRoute>
              <Dashboard />
            </PrivateRoute>
          }
        />
        
       

      </Routes>
      
    </BrowserRouter>
    
     
    {/* <Link to="/form">Form</Link> */}
      <div>

        {/* <Data/> */}
      </div>
    </div>
  );
}

export default App;
