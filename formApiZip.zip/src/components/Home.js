import './Data.css'
import React from 'react'

import { Link } from 'react-router-dom';

const Data = () => {

  return (
    <div>
      
      <div>
      <nav>
        <ul>
          <li>
          <Link to="/form">Register</Link> <br/>
          </li>
          <li>
          <Link to="/login">Login</Link><br/>
          </li>
          {/* <li>
          <Link to="/dashboard">Dashboard</Link><br/>
          </li> */}
      
        </ul>
      </nav>
  
      </div>
       <h2 style={{textAlign:"center"}}> Login Signup Using Api Authentication</h2>
      {/* <Link to="/form">Form</Link> */}
     
      </div>
   
  )
}

export default Data