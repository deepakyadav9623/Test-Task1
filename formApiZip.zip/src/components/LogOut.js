import React from 'react'
import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { getLogout } from '../redux/actions/actionCreator'
const LogOut = () => {
    const navigate=useNavigate()
    const dispatch = useDispatch()

    useEffect(()=>{
     fetchData();
    },[] )
    const fetchData = () => {
         dispatch(getLogout())
        localStorage.removeItem('token')
        localStorage.removeItem('user_id')
         navigate("/login")
        window.location.reload();
      }
      console.log("first")
  return (
    <div>LogOut</div>
  )
}

export default LogOut