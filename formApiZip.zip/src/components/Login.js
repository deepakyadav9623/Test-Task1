import React from 'react'
import { useForm } from 'react-hook-form'
import { useDispatch,useSelector } from 'react-redux';
import { LoginData } from '../redux/actions/actionCreator'
import { Link, useNavigate } from 'react-router-dom';
import { useEffect } from 'react';
import { useState } from 'react';

export const Login = () => {
    
    const {register,handleSubmit,formState:{errors},}=useForm();
    const dispatch=useDispatch();
    const [loginMessage, SetLoginMessage]=useState("")
    const login1=useSelector(state=> state.Reducer1.login)
    const error=useSelector(state=>state.Reducer1.error)
    const navigate=useNavigate()
    const token=localStorage.getItem("token");
    useEffect(()=>{

      if(token){
        navigate("/dashboard");
        window.location.reload();
      }
     
    },[token])
    const onSubmit = (data) => {
      console.log("login clicked")
      dispatch(LoginData(data))
          
        }

        const registerOptions = {
          email: { required: "Email is required" },
          password: {
            required: "Password is required",
            pattern:{
            value:/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,15}$/,
            message:"Password must contain an UpperCase,LowerCase,Number & b/W 6 to 15 characters"
          }
          
        }
      };

  
      // const loginMessage=localStorage.getItem('loginMessage')
      return (
        <div>
         <Link to="/">Back to home!!!</Link><br/><br/>
       
      <form onSubmit={handleSubmit(onSubmit)}> 
          <div>
            <label htmlFor="email">Email address : </label>
            <input type="email" {...register("email", registerOptions.email)} />
            <p style={{ color: "red" }}>
              {errors.email && errors.email.message}
            </p>
          </div>

          <div>
            <label htmlFor="password">Password : </label>
            <input
              type="password"
              {...register("password", registerOptions.password)}
            />
            <p style={{ color: "red" }}>
              {errors.password && errors.password.message}
            </p>
          </div>
          <input type="submit" />

      </form>
      <br/>
      <div>{ error && <p>Email and Password Is Incorrect</p>}</div>
      {/* {loginMessage} */}
    </div>
  );
}
