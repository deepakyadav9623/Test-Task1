import React from 'react'
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux'
import { registerData,  } from '../redux/actions/actionCreator'
import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';



export const Form = () => {
  const { register, handleSubmit, formState: { errors }, } = useForm();
  const [message, setMessage] = useState('');
 const navigate=useNavigate();
  const dispatch=useDispatch()
  const register1=useSelector(state=> state.Reducer1.register)
  const error=useSelector(state=>state.Reducer1.registerError)
  const onSubmit2 = (data) => {
    setMessage(register1.message)
    dispatch(registerData(data)) ;
    // navigate("/login")
    //  alert("Data Submitted Successfully")
  }
  const login=()=>{
    console.log("Clicked!!!")
     navigate("/login")
  }

  const registerOptions = {
    fullName: { required: "Name is required" },
    email: { required: "Email is required" },
  
    password: {
      required: "Password is required",
      pattern:{
        value:/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,15}$/,
        message:"Password must contain an UpperCase,LowerCase,Number & b/W 6 to 15 characters"
      }

    }
  };
  // console.log(register1.message)
    return (
      
      <div>
         <Link to="/">Back to home!!!</Link><br/>
        <br/>
        <form onSubmit={handleSubmit(onSubmit2)}>
       
          <div>
            <label htmlFor="email">Email address</label>
            <input type="email" {...register("email", registerOptions.email)} />
            <p style={{ color: "red" }}>
              {errors.email && errors.email.message}
            </p>
          </div>
          
          <div>
            <label>Password</label>
            <input
              type="password"
              {...register("password", registerOptions.password)}
            />
            <p style={{ color: "red" }}>
              {errors.password && errors.password.message}
            </p>
          </div>
          <div>
            <label >Confirm Password</label>
            <input
              type="password"
              {...register("password_confirmation", registerOptions.password)}
            />
            <p style={{ color: "red" }}>
              {errors.password && errors.password.message}
            </p>
          </div>
          <div>
          
          </div>
          <input type="submit" />
        </form> <br/>
       
        {register1.message } 
        {register1.message ?  <div> <button onClick={()=>{login()}}> Login  </button></div>: <div>{ error && <p>Already user</p>}</div> }
      {/* // <div> <button onClick={()=>{login()}}> Login  </button></div> */}
      </div>
    );
}



