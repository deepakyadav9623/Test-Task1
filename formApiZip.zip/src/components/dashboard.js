import React from 'react'
import { useEffect } from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'
import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useForm } from 'react-hook-form'
import { registerPost,deletedPost,updatedPost,getPost } from '../redux/actions/actionCreator'
import UpdatePost from './updatePost'
import { toast } from "react-toastify";



const Dashboard = () => {
// const [data1,Setdata1]=useState([]);
const [isVisible,SetisVisible]=useState(false);
const { register, handleSubmit, formState: { errors }, } = useForm();
const dispatch=useDispatch()
// const post =useSelector(state=>state.Reducer1.post)
const login1=useSelector(state=> state.Reducer1.login)
const data1=useSelector(state=>state)
const [ids,Setids]=useState();
const [title,Settitle]=useState();
const [description,Setdescription]=useState();

console.log(5555555555,data1)
// console.log(444444444,data1.Reducer1.deletePost.success)



// useEffect(()=>{
//   if(data1.Reducer1.deletePost.success){
//   toast.success(`Deleted`)
  
//   }
//   },[data1.Reducer1])

useEffect(()=>{
  if(data1?.Reducer1?.updatePost?.success){
    toast.success(`Up[dated]`)
    dispatch(getPost())
    
    }
    dispatch(getPost())

},[data1?.Reducer1?.deletePost,data1?.Reducer1?.registerPost,data1?.Reducer1?.updatePost])
const addPost=(data)=>{

    console.log("addPost Clicked",data)
    dispatch(registerPost(data))
}
const deletePost=(id)=>{
    console.log("Deleted",id)
    dispatch(deletedPost(id))
}
const EditPost=(id,title,description)=>{
    console.log("Edited",id)
    console.log("Edited",title)
    console.log("Edited",description)
    SetisVisible(true)
    Setids(id);
    Settitle(title);
    Setdescription(description);


}
const closeModal=()=>{
    console.log("Modal Closed",)
    SetisVisible(false)

}
const updatePost=(id,title,description)=>{
  console.log("Updated",id,title,description)
  dispatch(updatedPost(id,title,description))
    // SetisVisible(false)
    isVisible && SetisVisible(false);

}
const handleChange=()=>{
    console.log("handle change event")
}
const id=localStorage.getItem("user_id")
console.log("first",id)

  return (
    <div>
      { isVisible &&

      <UpdatePost isVisible={isVisible} closeModal={closeModal} ids={ids}  title={title} description={description} updatePost={updatePost} />
      }
      {/* <Link to="/">Back to home!!!</Link><br/> */}
      <Link to="/logout">LogOut!!!</Link>
      <br />
      User Id:- {id} <br/>

      <br />
      <div>
      
        Create New Post
        <br />
        <form onSubmit={handleSubmit(addPost)}>
          <input placeholder='Title'
            {...register("title",)}
          />
          <input placeholder='Description' {...register("description",)} />
          {/* <input placeholder='User_id' type="number" {...register("user_id",)} /> */}
          <input type="submit" />
        </form>
      </div>

      <br />
      <center>
      <table cellSpacing={20} border={5} >
            <tr>
                <th> id</th>
                <th> title</th>
                <th> Description</th>
               
            </tr>
         
            {data1?.Reducer1?.getPost?.posts?.map((user, index) => {
        return (
          <tr key={index}>
            {/* { isVisible===true ? 
            <input type="text"  onChange={()=>handleChange()} />: */}
              <> 
                 <td> {user.id}</td>  
                 <td>   {user.title} </td>  
                 <td>   {user.description} </td>  
                
                 <td><button onClick={()=>deletePost(user.id)}> Delete</button> 
                 <button onClick={()=>EditPost(user.id,user.title,user.description)}>  Edit</button></td>
                 </>
            {/* } */}
            
          </tr>
        );
      })}
         </table>
        </center>
   
    </div>
  );
}

export default Dashboard