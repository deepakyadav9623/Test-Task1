import axios from "axios"
// import { useNavigate } from "react-router-dom"
// import { NavigationActions } from 'react-navigation'

const REGISTER_DATA="REGISTER_DATA"
const REGISTER_POST="REGISTER_POST"
const DELETE_POST="DELETE_POST"
const UPDATE_POST="UPDATE_POST"
const GET_POST="GET_POST"
const LOGIN_DATA="LOGIN_DATA"
const GET_REGISTER_ERROR="GET_REGISTER_ERROR"
const GET_REGISTERPOST_ERROR="GET_REGISTERPOST_ERROR"
const GET_POST_ERROR="GET_POST_ERROR"
const GET_DELETEPOST_ERROR="GET_DELETEPOST_ERROR"
const GET_UPDATEPOST_ERROR="GET_UPDATEPOST_ERROR"
const GET_LOGIN_ERROR="GET_LOGIN_ERROR"
const GET_LOGOUT_SUCCESS="GET_LOGOUT_SUCCESS"

  export const registerData = (data) => {
    // console.log(" action",data)
    const user={email:data.email,password:data.password,password_confirmation:data.password_confirmation}
    return (dispatch)=>{
        axios.post(`https://react-rails-api-demo.herokuapp.com/api/v1/signup`,  {user} )
        .then((res)=>{
            dispatch(registerDataSuccess(res.data))
        }).catch((error)=>{
            dispatch(getRegisterError(error.message))
        })
    }
  }

  export const getPost = (data) => {
    const config={
        headers:{
            // 'Authorization': `Bearer ${token}`
            'Authorization': localStorage.getItem('token') 
        }
    };
    return (dispatch)=>{
        axios.get(`https://react-rails-api-demo.herokuapp.com/api/v1/posts`, config )
        .then((res)=>{
            dispatch(getPostSuccess(res.data))
          
        }).catch((error)=>{
            dispatch(getPostError(error.message))
        })
    }
  }

  export const registerPost = (data) => {
    const id=localStorage.getItem("user_id")

    // console.log(" action",data)
    const post={title:data.title,description:data.description,user_id:id}
    const config={
        headers:{
            // 'Authorization': `Bearer ${token}`
            'Authorization': localStorage.getItem('token') 
        }
    };
    return (dispatch)=>{
        axios.post(`https://react-rails-api-demo.herokuapp.com/api/v1/posts`,  {post},config )
        .then((res)=>{
            dispatch(registerPostSuccess(res.data))
        }).catch((error)=>{
            dispatch(getRegisterPostError(error.message))
        })
    }
  }
  export const deletedPost = (data) => {
    const config={
        headers:{  
            // 'Authorization': `Bearer ${token}`
            'Authorization': localStorage.getItem('token') 
        }
    };
    return (dispatch)=>{
        axios.delete(`https://react-rails-api-demo.herokuapp.com/api/v1/posts/${data}` ,config)
        .then((res)=>{
            dispatch(deletePostSuccess(res.data))
        }).catch((error)=>{
            dispatch(getdeletePostError(error.message))
        })
    }
  }
  export const updatedPost = (id,title,description) => {
    const post={title:title,description:description}
    const config={
        headers:{
            // 'Authorization': `Bearer ${token}`
            'Authorization': localStorage.getItem('token') 
        }
    };
    return (dispatch)=>{
        axios.put(`https://react-rails-api-demo.herokuapp.com/api/v1/posts/${id}`,{post} ,config)
        .then((res)=>{
            dispatch(updatePostSuccess(res.data))
        }).catch((error)=>{
            dispatch(getupdatePostError(error.message))
        })
    }
  }
  
  export const LoginData = (data) => {
    // const navigate=useNavigate();
    const user={email:data.email,password:data.password}

    return (dispatch)=>{
        axios.post(`https://react-rails-api-demo.herokuapp.com/api/v1/signin`, {user}  )
        .then((res)=>{
           console.log("11111",res.data)
            localStorage.setItem('token',(res.data.token));
            localStorage.setItem('user_id',(res.data.user.id));
            dispatch(loginDataSuccess(res.data))
            // navigate("/dashboard");
        }).catch((error)=>{
            dispatch(getLoginError(error.message))
        })
    }
  }
 

 
 
  const registerDataSuccess=(data)=>{
      return{
          type:REGISTER_DATA,
          payload:data
      }
  }
  const registerPostSuccess=(data)=>{
      return{
          type:REGISTER_POST,
          payload:data
      }
  }
  const getPostSuccess=(data)=>{
      return{
          type:GET_POST,
          payload:data
      }
  }
  const deletePostSuccess=(data)=>{
      return{
          type:DELETE_POST,
          payload:data
      }
  }
  const updatePostSuccess=(data)=>{
      return{
          type:UPDATE_POST,
          payload:data
      }
  }
  const loginDataSuccess=(data)=>{
      return{
          type:LOGIN_DATA,
          payload:data
      }
  }
  
  const getRegisterError=(data)=>{
      return{
          type:GET_REGISTER_ERROR,
          payload:data
      }
  }
  const getRegisterPostError=(data)=>{
      return{
          type:GET_REGISTERPOST_ERROR,
          payload:data
      }
  }
  const getPostError=(data)=>{
      return{
          type:GET_POST_ERROR,
          payload:data
      }
  }
  const getdeletePostError=(data)=>{
      return{
          type:GET_DELETEPOST_ERROR,
          payload:data
      }
  }
  const getupdatePostError=(data)=>{
      return{
          type:GET_UPDATEPOST_ERROR,
          payload:data
      }
  }
  const getLoginError=(data)=>{
      return{
          type:GET_LOGIN_ERROR,
          payload:data
      }
  }


  export const getLogout = (data) => {
    return dispatch => {
      dispatch(getLogoutSuccess());
    };
  };
  
  
  const getLogoutSuccess = () => ({
    type: GET_LOGOUT_SUCCESS
  });
  
  