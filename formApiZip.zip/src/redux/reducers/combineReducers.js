import { combineReducers } from "redux";
import Reducer1 from "./reducers";
const rootReducer= combineReducers({
    Reducer1
})

export default rootReducer;