
const initialState={
   
    // error:"",
    register:[],
    login:[],
    getPost:[],
    deletePost:[],

}
const Reducers = (state = initialState,action) => {
    console.log(666666666, action.type);
    console.log(666611111, action.payload);
    

    switch (action.type) {
      
      case "REGISTER_DATA":
        return { ...state, register:(action.payload),error:null };
      case "REGISTER_POST":
        return { ...state,  registerPost: (action.payload) };
      case "GET_POST":
        return { ...state,  getPost:action.payload,error:null };
      case "DELETE_POST":
        return { ...state,  deletePost:action.payload };
      case "UPDATE_POST":
        return { ...state,  updatePost:action.payload };
      case "LOGIN_DATA":
        return { ...state, login: action.payload,error:null };
 
      case "GET_LOGIN_ERROR":
        return { ...state, error: action.payload };
      case "GET_POST_ERROR":
        return { ...state, getPosterror: action.payload };
      case "GET_REGISTER_ERROR":
        return { ...state, registerError: action.payload };
      case "GET_REGISTERPOST_ERROR":
        return { ...state, registerPostError: action.payload };
      case "GET_DELETEPOST_ERROR":
        return { ...state, deletePostError: action.payload };
      case "GET_UPDATEPOST_ERROR":
        return { ...state, updatePostError: action.payload };
      case "GET_LOGOUT_SUCCESS":
        return { ...state, error:false,login:null };
   
      default:
        return state;
    }
}

export default Reducers;