
import axios from "axios"
import { call, put, takeEvery } from 'redux-saga/effects'
import {REGISTER_DATA_REQUESTED,REGISTER_DATA,GET_REGISTER_ERROR} from '../actions/actionCreator'

function registerApi(data){
    const user={
        email:data.email,
        password:data.password,
        password_confirmation:data.password_confirmation
    }
    return axios.request({
        method:'POST',
        url:'https://react-rails-api-demo.herokuapp.com/api/v1/signup',
        data:{user}
    })
}

function* registerUser(action){
    try {
        const response=yield call(registerApi,action.payload)
        yield put({type:REGISTER_DATA,register:response.data})
        
    } catch (error) {
        yield put({type:GET_REGISTER_ERROR,error:error.message})
    }

}

function* UserSaga(){
    yield takeEvery(REGISTER_DATA_REQUESTED,registerUser)
}

export default UserSaga;