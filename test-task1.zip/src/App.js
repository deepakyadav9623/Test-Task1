import './App.css';
import Configuration from './Configuration';

function App() {
  return (
    <div >
     
        
       <Configuration/>
     
    </div>
  );
}

export default App;
