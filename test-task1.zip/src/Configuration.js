import React, { useState } from 'react'

const Configuration = () => {
    const [color,Setcolor]=useState("")
    const [power,Setpower]=useState("")
    const [warp,Setwarp]=useState("")
    const [option,Setoption]=useState("")
    const [basePrice,SetbasePrice]=useState(1000)

    const white=()=>{
       Setcolor(0);
        
    }
    const orange=()=>{
       Setcolor(100);
        
    }
    const blue=()=>{
       Setcolor(200);
        
    }
    const low=()=>{
       Setpower(0);
        
    }
    const high=()=>{
       Setpower(200);
        
    }
    const extreme=()=>{
       Setpower(500);
        
    }
    const warpNo=()=>{
       Setwarp(0);
        
    }
    const warpYes=()=>{
       Setwarp(1000);
        
    }
    const optionBasic=()=>{
       Setoption(0);
        
    }
    const optonSports=()=>{
       Setoption(100);
        
    }
    const optionLux=()=>{
       Setoption(500);
        
    }
    const whiteHover=()=>{
        console.log("white 11111Clicked")
        
    }
  return (
    <div class="container ">
        <div class="col-6 col-lg-6  border "   >
        <div >
        <p> Select Color</p>
        <button onClick={white} onMouseOver={whiteHover} className="btn btn-light"> White <br/> 0$ </button> &nbsp;
        <button onClick={orange} class="btn btn-danger" > Orange <br/> 100$</button> &nbsp;
        <button onClick={blue} class="btn btn-info" > Blue <br/> 200$ </button>
        </div>
        <div>
        <p> Select Power</p>
        <button onClick={low} class="btn btn-outline-warning"> 100 MW <br/> 0$  </button> &nbsp;
        <button onClick={high} class="btn btn-outline-secondary"> 200 MW <br/> 200$ </button> &nbsp;
        <button onClick={extreme} class="btn btn-outline-danger"> 300 MW <br/> 500$ </button>
        </div>
        <div>
        <p> Warp Drive</p>
        <button onClick={warpNo}  class="btn btn-outline-primary"> No  <br/> 0$ </button> &nbsp;
        <button onClick={warpYes} class="btn btn-outline-info"> Yes  <br/> 1000$ </button> &nbsp;
        </div>
        <div>
        <p> Select Option Package</p>
        <button onClick={optionBasic} class="btn btn-outline-warning"> Basic  <br/> 0$</button> &nbsp;
        <button onClick={optonSports} class="btn btn-outline-secondary"> Sports <br/> 100$</button> &nbsp;
        <button onClick={optionLux} class="btn btn-outline-success"> Lux <br/> 500$</button>
        </div>
        </div>
<br/>
<br/>


        <div class="col-6 col-lg-6 border border-success p-0 text-center bg-success p-2 text-white bg-opacity-75" >
            <p>Base Price :{basePrice}$</p>
            <p>Color:{color}$</p>
            <p>Power:{power}$  </p>
            <p>Warp drive:{warp} $ </p>
            <p>Option Package:{option}$  </p>

          <p> Total :{basePrice+color+power+warp+option} $</p> 
        </div>
    </div>
  )
}

export default Configuration