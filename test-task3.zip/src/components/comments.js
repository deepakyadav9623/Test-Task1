import React from 'react'
import { useSelector } from 'react-redux'
import { useParams } from 'react-router'
import { useNavigate } from 'react-router'

const Comments = () => {
    const navigate=useNavigate()
    const {id}=useParams()
    const data=useSelector(state=>state)
    console.log(666666,data.Reducers.getComments)
  return (
    <div className='App-header'>
         <div>
            <button onClick={() => navigate(-1)}> Back!!!</button>
        </div>
        <br/>
        <div>
             {data.Reducers.getComments.filter((item)=>item.postId==id).map((items,index)=>{
                 return(
                     <div key={index}>
                         <p>  Commentators Name :  {items.name}</p>
                         <p> Comments Body :  {items.body}</p>
                         <p>  Commentators Email :  {items.email}</p>
                         <br/>
                         <br/>
                     </div>
                 )
             })}
            
        </div>

        </div>
  )
}

export default Comments