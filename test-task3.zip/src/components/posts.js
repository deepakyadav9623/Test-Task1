import React from 'react'
import { useSelector } from 'react-redux';
import { useParams } from 'react-router';
import { useNavigate } from 'react-router'

const Posts = () => {
    const navigate=useNavigate();
    const ids=useParams()
    const data=useSelector(state=>state)
    console.log(55555,data)

    const commentsDetails=(id)=>{
        navigate(`/comments/${id}`)
    }
  return (
    <div className='App-header'>
        <div>
            <button onClick={() => navigate(-1)}> Back!!!</button>
        </div><br/>
        <h1>Posts Detail of Post No. {ids.id}</h1>
        <br/>
        <br/>
        <div> { data.Reducers.getPost.filter((item)=>item.id==ids.id).map((posts,index)=>{
            console.log(88777,posts)
            return(
            <div key={index}>
                {/* <p> Id : {posts.id}</p> */}
                <p onClick={()=>{commentsDetails(posts.id)}}>  Title :  {posts.title}</p>
                {/* <p>  Body :  {posts.body}</p>
                <p>  UserId : {posts.userId}</p> */}
                <p>  User Name : {data.Reducers.getUsers.filter((item)=>item.id==posts.userId).map((item)=>item.username)}</p>
            </div>
            )
        })}</div>
    </div>
  )
}

export default Posts